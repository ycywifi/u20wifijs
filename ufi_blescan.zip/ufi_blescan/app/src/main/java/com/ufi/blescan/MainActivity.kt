package com.ufi.blescan

import android.Manifest
import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var tvPath: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etMac: EditText
    private lateinit var tvData: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var refreshTask: Runnable? = null

    companion object {
        private const val REQ_PERM = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPath = findViewById(R.id.tv_path)
        tvStatus = findViewById(R.id.tv_status)
        etMac = findViewById(R.id.et_mac)
        tvData = findViewById(R.id.tv_data)
        tvData.movementMethod = ScrollingMovementMethod()

        tvPath.text = LogStore.getLogFile(this).absolutePath

        findViewById<Button>(R.id.btn_start).setOnClickListener {
            val mac = etMac.text.toString().trim()
            if (mac.isNotEmpty() && !mac.matches(Regex("^[0-9A-Fa-f:]{11,17}$"))) {
                Toast.makeText(this, "MAC 格式不正确", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Prefs.setMacFilter(this, mac)
            ensurePermissions { startScanService() }
        }

        findViewById<Button>(R.id.btn_stop).setOnClickListener {
            stopScanService()
        }

        findViewById<Button>(R.id.btn_view).setOnClickListener {
            showRecent()
        }

        registerReceiver(statusReceiver, IntentFilter(BleScanService.ACTION_STATUS).apply {
            addAction(BleScanService.ACTION_ERROR)
        })

        refreshStatus()
        startAutoRefresh()
    }

    private fun ensurePermissions(onGranted: () -> Unit) {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.BLUETOOTH_SCAN)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isEmpty()) {
            onGranted()
        } else {
            ActivityCompat.requestPermissions(this, need.toTypedArray(), REQ_PERM)
            pendingAction = onGranted
        }
    }

    private var pendingAction: (() -> Unit)? = null

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val ok = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (ok) pendingAction?.invoke() else Toast.makeText(this, "权限被拒绝", Toast.LENGTH_SHORT).show()
            pendingAction = null
        }
    }

    private fun startScanService() {
        val i = Intent(this, BleScanService::class.java).setAction(BleScanService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(i)
        } else {
            startService(i)
        }
        handler.postDelayed({ refreshStatus() }, 800)
    }

    private fun stopScanService() {
        startService(Intent(this, BleScanService::class.java).setAction(BleScanService.ACTION_STOP))
        handler.postDelayed({ refreshStatus() }, 500)
    }

    private fun isServiceRunning(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (s in am.getRunningServices(Int.MAX_VALUE)) {
            if (BleScanService::class.java.name == s.service.className) return true
        }
        return false
    }

    private fun refreshStatus() {
        val f = LogStore.getLogFile(this)
        val running = isServiceRunning()
        val lines = if (f.exists()) LogStore.countLines(f) else 0
        val total = LogStore.totalBytes(this)
        tvStatus.text = buildString {
            append(if (running) "采集运行中" else "未运行")
            append("　当前：${lines} 行")
            append("　总量：${total / 1024} KB / ${LogStore.MAX_TOTAL_BYTES / 1024 / 1024} MB")
        }
    }

    private fun startAutoRefresh() {
        refreshTask = object : Runnable {
            override fun run() {
                refreshStatus()
                handler.postDelayed(this, 3000)
            }
        }
        handler.postDelayed(refreshTask!!, 3000)
    }

    private fun showRecent() {
        val f = LogStore.getLogFile(this)
        if (!f.exists()) {
            tvData.text = "(暂无数据)"
            return
        }
        tvData.text = LogStore.tail(f, 30).ifEmpty { "(暂无数据)" }
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                BleScanService.ACTION_STATUS -> refreshStatus()
                BleScanService.ACTION_ERROR ->
                    tvStatus.text = "错误：${i.getStringExtra(BleScanService.EXTRA_MSG)}"
            }
        }
    }

    override fun onDestroy() {
        refreshTask?.let { handler.removeCallbacks(it) }
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
