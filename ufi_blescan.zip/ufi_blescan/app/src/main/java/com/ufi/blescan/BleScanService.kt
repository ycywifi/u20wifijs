package com.ufi.blescan

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log

/**
 * BLE 温湿度采集前台服务。
 *
 * 监听米家温湿度计2（LYWSD03MMC，刷 pvvx 固件后广播 ATC1441）的 BLE 广播，
 * 解析 Service Data（16-bit UUID 0x181A），追加写入日志文件。
 *
 * 要点：
 *  - 前台服务 + START_STICKY，尽量不被系统回收
 *  - 持 PARTIAL_WAKE_LOCK，保证息屏后仍持续扫描
 *  - 被杀/被划卡片后重启（onTaskRemoved）
 *  - 日志单文件上限 5MB，超出自动轮转
 */
class BleScanService : Service() {

    companion object {
        const val TAG = "UFI_BLE"
        const val CHANNEL_ID = "ufi_ble_scan"
        const val NOTIF_ID = 1

        const val ACTION_START = "com.ufi.blescan.START"
        const val ACTION_STOP = "com.ufi.blescan.STOP"
        const val ACTION_STATUS = "com.ufi.blescan.STATUS"
        const val ACTION_ERROR = "com.ufi.blescan.ERROR"
        const val EXTRA_MSG = "msg"

        /** ATC1441 广播的 Service UUID：0x181A（Environmental Sensing） */
        val UUID_181A: java.util.UUID =
            java.util.UUID.fromString("0000181A-0000-1000-8000-00805F9B34FB")

        /** 同一设备相同计数的广播只记一次，避免多信道重复 */
        private const val DEDUP_WINDOW_MS = 1500L
    }

    private var scanner: BluetoothLeScanner? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var running = false

    /** MAC(归一化) -> 上次记录的 (计数, 时间戳)，用于去重 */
    private val lastSeen = HashMap<String, Pair<Int, Long>>()

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            handleResult(result)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { handleResult(it) }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e(TAG, "SCAN_FAILED=$errorCode")
            broadcast(ACTION_ERROR, "扫描失败 code=$errorCode（请确认蓝牙已开启、位置服务已开）")
            // 5 秒后重试
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                if (running) startScanInternal()
            }, 5000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        LogStore.enforceQuotaOnStart(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification("采集中"))
        acquireWakeLock()

        when (intent?.action) {
            ACTION_STOP -> {
                stopScanInternal()
                releaseWakeLock()
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                if (!running) startScanInternal()
            }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // 被从最近任务划掉时重新启动，保证持续采集
        val restart = Intent(applicationContext, BleScanService::class.java).apply {
            action = ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restart)
        } else {
            startService(restart)
        }
        super.onTaskRemoved(rootIntent)
    }

    private fun startScanInternal() {
        val bm = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter: BluetoothAdapter? = bm?.adapter
        if (adapter == null) {
            broadcast(ACTION_ERROR, "本机无蓝牙适配器")
            return
        }
        if (!adapter.isEnabled) {
            broadcast(ACTION_ERROR, "蓝牙未开启")
            // 尝试自行开启（需 BLUETOOTH_ADMIN；部分 ROM 会静默失败）
            @Suppress("DEPRECATION")
            runCatching { adapter.enable() }
            return
        }

        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            broadcast(ACTION_ERROR, "无法获取 BLE 扫描器")
            return
        }

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setReportDelay(0)
            .build()

        runCatching {
            scanner?.startScan(null, settings, scanCallback)
            running = true
            Log.i(TAG, "scan started")
            updateNotification("采集中")
            broadcast(ACTION_STATUS)
        }.onFailure {
            broadcast(ACTION_ERROR, "启动扫描异常：${it.message}")
        }
    }

    private fun stopScanInternal() {
        runCatching { scanner?.stopScan(scanCallback) }
        running = false
        Log.i(TAG, "scan stopped")
    }

    /**
     * 解析 ATC1441 广播。
     * Service Data 布局：
     *   [0..5]  MAC
     *   [6..7]  温度 int16 大端有符号，实际值 = raw / 10.0
     *   [8]     湿度 %
     *   [9]     电量 %
     *   [10..11] 电压 mV uint16 大端
     *   [12]    计数
     */
    private fun handleResult(result: ScanResult) {
        val data = result.scanRecord?.serviceData?.get(android.os.ParcelUuid(UUID_181A))
            ?: return
        if (data.size < 13) return

        val mac = result.device.address ?: return

        // MAC 过滤（插件/界面可配置）
        val filter = Prefs.getMacFilter(this)
        if (filter.isNotEmpty() &&
            !mac.replace(":", "").equals(filter.replace(":", ""), ignoreCase = true)
        ) return

        val rawTemp = ((data[6].toInt() and 0xFF) shl 8) or (data[7].toInt() and 0xFF)
        val signed = if (rawTemp > 32767) rawTemp - 65536 else rawTemp
        val temp = signed / 10.0
        val humi = data[8].toInt() and 0xFF
        val batt = data[9].toInt() and 0xFF
        val volt = ((data[10].toInt() and 0xFF) shl 8) or (data[11].toInt() and 0xFF)
        val counter = data[12].toInt() and 0xFF
        val rssi = result.rssi

        // 去重：同一 MAC 相同计数在窗口内只记一次
        val now = SystemClock.elapsedRealtime()
        val key = mac.replace(":", "")
        val last = lastSeen[key]
        if (last != null && last.first == counter && now - last.second < DEDUP_WINDOW_MS) return
        lastSeen[key] = counter to now

        val now = System.currentTimeMillis()
        val timeText = TimeUtil.format(now)
        val line = "$now $timeText $mac $temp $humi $batt $volt $rssi"
        LogStore.append(this, line)
        broadcast(ACTION_STATUS)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("BLE 温湿度采集")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "BLE 采集", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "BLE 温湿度采集常驻通知" }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ufi_blescan:scan").apply {
            acquire(6 * 60 * 60 * 1000L) // 6 小时，服务存活期内持续持有
        }
    }

    private fun releaseWakeLock() {
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
    }

    private fun broadcast(action: String, msg: String? = null) {
        val i = Intent(action).setPackage(packageName)
        if (msg != null) i.putExtra(EXTRA_MSG, msg)
        sendBroadcast(i)
    }

    override fun onDestroy() {
        stopScanInternal()
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
