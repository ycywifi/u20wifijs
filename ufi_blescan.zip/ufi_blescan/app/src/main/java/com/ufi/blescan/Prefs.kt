package com.ufi.blescan

import android.content.Context

/** 轻量配置存储（MAC 过滤等） */
object Prefs {
    private const val NAME = "ufi_blescan"
    private const val KEY_MAC = "mac_filter"

    fun setMacFilter(context: Context, mac: String) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_MAC, mac).apply()
    }

    fun getMacFilter(context: Context): String =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getString(KEY_MAC, "") ?: ""
}
