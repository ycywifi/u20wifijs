package com.ufi.blescan

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * 开机 / 解锁 / 应用升级后自动拉起采集服务。
 *
 * 这是插件「写入 App 开机自启」能生效的前提：
 * 没有这个 Receiver，am broadcast BOOT_COMPLETED 发出去也没人接收。
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.i("UFI_BLE", "BootReceiver action=$action")

        // 蓝牙未开启时不启动，避免在不支持的环境里反复失败
        val bm = context.getSystemService(Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager
        if (bm?.adapter?.isEnabled != true) {
            Log.w("UFI_BLE", "bluetooth disabled, skip autostart")
            return
        }

        val i = Intent(context, BleScanService::class.java).apply {
            setAction(BleScanService.ACTION_START)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        } catch (e: Exception) {
            Log.e("UFI_BLE", "autostart failed: ${e.message}")
        }
    }
}
