package com.ufi.blescan

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 时间格式化工具。
 *
 * 输出形如：2026-09-17_11:42:03
 *
 * 两个设计要点：
 *  1. 日期与时间之间用【下划线】而不是空格连接。
 *     配套插件用 shell 分词解析日志行，空格会把它拆成两个字段；
 *     而 "2026-09-17" 含减号，会被误判为负数形式的"数值"列，
 *     从而污染 温度/湿度 等字段的提取。
 *  2. SimpleDateFormat 非线程安全，BLE 回调不在主线程，故加锁。
 */
object TimeUtil {

    private const val PATTERN = "yyyy-MM-dd_HH:mm:ss"
    private val lock = Any()

    @Suppress("SimpleDateFormat") // 固定格式输出，与系统 Locale 无关
    private val formatter = SimpleDateFormat(PATTERN, Locale.US)

    /** 格式化为 2026-09-17_11:42:03 */
    fun format(millis: Long): String = synchronized(lock) {
        formatter.format(Date(millis))
    }
}
