package com.ufi.blescan

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile

/**
 * 日志文件管理（总量配额）。
 *
 * 路径：/sdcard/Android/data/com.ufi.blescan/files/ble.log
 *
 * 配额规则：
 *  - 所有 ble.log* 文件的【总大小】不超过 5MB（不是单文件上限）
 *  - 当前文件写满 ROTATE_BYTES(512KB) 后轮转：
 *      ble.log.2 -> ble.log.3
 *      ble.log.1 -> ble.log.2
 *      ble.log   -> ble.log.1
 *    然后新建空的 ble.log 继续写
 *  - 轮转后检查总量，超出则从最旧的（序号最大的）开始删除，直到总量 ≤ 5MB
 *
 * 注意：配套插件只读取 ble.log，轮转后该文件从 0 开始，
 *      插件会通过"文件变小"检测到轮转并重置读取偏移，不会漏采。
 */
object LogStore {

    /** 所有日志文件总大小上限：5MB */
    const val MAX_TOTAL_BYTES = 5L * 1024 * 1024

    /**
     * 安全余量。配额检查每 QUOTA_CHECK_LINES 行才做一次，
     * 两次检查之间总量会继续增长，预留余量确保任何时刻都不会突破 5MB。
     */
    private const val SAFETY_MARGIN = 256 * 1024L
    private const val SOFT_LIMIT = MAX_TOTAL_BYTES - SAFETY_MARGIN

    /** 当前文件达到该大小即轮转 */
    private const val ROTATE_BYTES = 512 * 1024L

    private const val FILE_NAME = "ble.log"
    private const val HISTORY_PREFIX = "ble.log."

    /** 每写多少行检查一次总配额，避免频繁 stat */
    private const val QUOTA_CHECK_LINES = 20

    private val lock = Any()
    private var linesSinceCheck = 0

    fun getDir(context: Context): File {
        @Suppress("DEPRECATION")
        val ext: File? = context.getExternalFilesDir(null)
        return ext ?: context.filesDir
    }

    fun getLogFile(context: Context): File = File(getDir(context), FILE_NAME)

    /** 当前 + 历史文件的总字节数 */
    fun totalBytes(context: Context): Long = totalBytes(getDir(context))

    private fun totalBytes(dir: File): Long {
        var sum = 0L
        listAll(dir).forEach { sum += it.length() }
        return sum
    }

    /** 返回 [当前文件, 历史1, 历史2 ...]（历史按序号升序，即由新到旧） */
    private fun listAll(dir: File): List<File> {
        val result = mutableListOf<File>()
        File(dir, FILE_NAME).let { if (it.exists()) result.add(it) }
        val history = (dir.listFiles() ?: emptyArray())
            .filter { it.name.startsWith(HISTORY_PREFIX) }
            .mapNotNull { f ->
                f.name.removePrefix(HISTORY_PREFIX).toIntOrNull()?.let { it to f }
            }
            .sortedBy { it.first }
            .map { it.second }
        result.addAll(history)
        return result
    }

    /** 追加一行 */
    fun append(context: Context, line: String) {
        synchronized(lock) {
            try {
                val dir = getDir(context)
                if (!dir.exists()) dir.mkdirs()
                val f = File(dir, FILE_NAME)

                if (f.exists() && f.length() >= ROTATE_BYTES) rotate(dir)

                FileOutputStream(f, true).use { out ->
                    out.write((line + "\n").toByteArray(Charsets.UTF_8))
                    out.flush()
                }

                if (++linesSinceCheck >= QUOTA_CHECK_LINES) {
                    linesSinceCheck = 0
                    enforceQuota(dir)
                }
            } catch (e: Exception) {
                Log.e("UFI_BLE", "append failed: ${e.message}")
            }
        }
    }

    /** 轮转：历史文件序号 +1，当前文件成为 .1，重建空 ble.log */
    private fun rotate(dir: File) {
        try {
            val history = (dir.listFiles() ?: emptyArray())
                .filter { it.name.startsWith(HISTORY_PREFIX) }
                .mapNotNull { f ->
                    f.name.removePrefix(HISTORY_PREFIX).toIntOrNull()?.let { it to f }
                }
                .sortedByDescending { it.first }   // 从旧到新处理，避免覆盖

            for ((index, file) in history) {
                val target = File(dir, HISTORY_PREFIX + (index + 1))
                if (target.exists()) target.delete()
                if (!file.renameTo(target)) file.delete()
            }

            val current = File(dir, FILE_NAME)
            val first = File(dir, HISTORY_PREFIX + "1")
            if (first.exists()) first.delete()
            if (!current.renameTo(first)) {
                // 重命名失败则直接清空，保证能继续写
                RandomAccessFile(current, "rw").use { it.setLength(0) }
            }
            Log.i("UFI_BLE", "log rotated")
        } catch (e: Exception) {
            Log.e("UFI_BLE", "rotate failed: ${e.message}")
            runCatching { RandomAccessFile(File(dir, FILE_NAME), "rw").use { it.setLength(0) } }
        }
    }

    /**
     * 配额控制：从最旧的（序号最大的）历史文件开始删除，
     * 直到总大小 ≤ MAX_TOTAL_BYTES。
     */
    private fun enforceQuota(dir: File) {
        try {
            var total = totalBytes(dir)
            if (total <= SOFT_LIMIT) return

            // 历史文件按序号降序 = 由旧到新，优先删旧的
            val history = (dir.listFiles() ?: emptyArray())
                .filter { it.name.startsWith(HISTORY_PREFIX) }
                .mapNotNull { f ->
                    f.name.removePrefix(HISTORY_PREFIX).toIntOrNull()?.let { it to f }
                }
                .sortedByDescending { it.first }
                .map { it.second }
                .toMutableList()

            for (f in history) {
                if (total <= SOFT_LIMIT) break
                val size = f.length()
                if (f.delete()) {
                    total -= size
                    Log.i("UFI_BLE", "quota: removed ${f.name}, total=$total")
                }
            }

            // 极端情况：只剩当前文件仍超软限（轮转阈值 < 5MB，理论上不会发生）
            val current = File(dir, FILE_NAME)
            if (total > SOFT_LIMIT && current.exists()) {
                RandomAccessFile(current, "rw").use { it.setLength(0) }
                Log.w("UFI_BLE", "quota: current file truncated")
            }
        } catch (e: Exception) {
            Log.e("UFI_BLE", "enforceQuota failed: ${e.message}")
        }
    }

    /** 启动时检查一次配额 */
    fun enforceQuotaOnStart(context: Context) {
        synchronized(lock) { enforceQuota(getDir(context)) }
    }

    fun countLines(f: File): Int {
        if (!f.exists()) return 0
        return try {
            f.bufferedReader(Charsets.UTF_8).useLines { it.count() }
        } catch (e: Exception) {
            0
        }
    }

    fun tail(f: File, n: Int): String {
        if (!f.exists()) return ""
        return try {
            f.readLines(Charsets.UTF_8).takeLast(n).joinToString("\n")
        } catch (e: Exception) {
            ""
        }
    }
}
