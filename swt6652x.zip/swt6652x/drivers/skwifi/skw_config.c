#include <linux/ctype.h>
#include <linux/firmware.h>

#include "skw_util.h"
#include "skw_config.h"
#include "skw_log.h"
#include "skw_regd.h"

#define SKW_LINE_BUFF_LEN   128

struct skwifi_cfg {
	char *name;
	int (*parser)(struct skwifi_cfg *cfg, char *key, char *data);
	void *priv;
};

static int skw_get_data(char *src, char *data, int data_size,
			char start_tag, char end_tag)
{
	int len;
	char *start, *end;

	start = strchr(src, start_tag);
	if (!start)
		return -EINVAL;

	end = strchr(start + 1, end_tag);
	if (!end)
		return -EINVAL;

	len = end - start - 1;
	if (len > data_size)
		return -ENOMEM;

	if (len > 0)
		memcpy(data, start + 1, len);

	return len;
}

static struct skwifi_cfg *skw_cfg_match(struct skwifi_cfg *table, char *name)
{
	int i;
	struct skwifi_cfg *cfg = NULL;

	for (i = 0; table[i].name != NULL; i++) {
		if (!strcmp(&name[1], table[i].name)) {
			cfg = &table[i];
			break;
		}
	}

	return cfg;
}

static void skw_parser(struct skwifi_cfg *table, const u8 *data, int size)
{
	char chr, line[SKW_LINE_BUFF_LEN];
	int space = 0, line_num = 0;
	int i = 0, nr = 0, token = 0;
	bool str_mode = false;
	bool number_mode = false;
	bool comment_mode = false;
	bool invalid_line = false;
	struct skwifi_cfg *cfg = NULL;

	for (i = 0; i < size; i++) {
		chr = data[i];

		if (chr == '\n' || chr == 0) {
			int len = nr, start = token;
			bool invalid = invalid_line;

			line_num++;

			if (number_mode || str_mode)
				invalid = true;

			nr = 0;
			token = 0;
			space = 0;

			str_mode = false;
			number_mode = false;
			comment_mode = false;
			invalid_line = false;

			if (len == 0 || invalid) {
				continue;
			}

			line[len] = 0;

			if (line[0] == '%') {
				cfg = skw_cfg_match(table, line);
				continue;
			}

			if (!cfg || !start)
				continue;

			cfg->parser(cfg, &line[0], &line[start]);

			continue;
		}

		if (nr >= sizeof(line))
			invalid_line = true;

		if (comment_mode || invalid_line)
			continue;

		if (str_mode) {
			line[nr++] = chr;

			if (chr == '"')
				str_mode = false;

			continue;
		}

		switch (chr) {
		case '#':
			comment_mode = true;
			break;

		case '"':
			if (token)
				str_mode = true;

			line[nr++] = chr;
			break;

		case '\r':
			break;

		case '=':
			line[nr++] = 0;
			token = nr;
			space = 0;

			break;

		case '<':
			if (token)
				number_mode = true;

			line[nr++] = chr;
			break;

		case '>':
			if (token && number_mode)
				number_mode = false;

			line[nr++] = chr;
			break;

		case ' ':
		case '\t':
			if (!token)
				space++;

			if (number_mode) {
				if (isxdigit(line[nr - 1]))
					line[nr++] = ',';
			}

			break;

		default:
			if(space) {
				if (nr)
					invalid_line = true;
				else
					space = 0;
			}

			if (!invalid_line)
				line[nr++] = chr;

			break;
		}
	}
}

static int skw_config_parser(struct skwifi_cfg *config, char *key, char *data)
{
	int len;
	long val;
	char *endp;
	char str[SKW_LINE_BUFF_LEN] = {0};
	struct skw_cfg_default *cfg = config->priv;

	if (cfg == NULL)
		return -EINVAL;

	if (!strcmp(key, "ifname0")) {
		len = skw_get_data(data, str, SKW_LINE_BUFF_LEN, '"', '"');
		if (len == 0)
			memset(cfg->ifname[0], 0x0, sizeof(cfg->ifname[0]));
		else if (len > 0)
			strncpy(cfg->ifname[0], str, sizeof(cfg->ifname[0]));
	} else if (!strcmp(key, "ifname1")) {
		len = skw_get_data(data, str, SKW_LINE_BUFF_LEN, '"', '"');
		if (len == 0)
			memset(cfg->ifname[1], 0x0, sizeof(cfg->ifname[1]));
		else if (len > 0)
			strncpy(cfg->ifname[1], str, sizeof(cfg->ifname[1]));
	} else if (!strcmp(key, "ifname2")) {
		len = skw_get_data(data, str, SKW_LINE_BUFF_LEN, '"', '"');
		if (len == 0)
			memset(cfg->ifname[2], 0x0, sizeof(cfg->ifname[2]));
		else if (len > 0)
			strncpy(cfg->ifname[2], str, sizeof(cfg->ifname[2]));
	} else if (!strcmp(key, "mac")) {
		int i, idx;
		char *pos, addr[8] = {0};

		if (skw_get_data(data, str, sizeof(str), '<', '>') <= 0)
			return 0;

		pos = &str[0];
		for (idx = 0, i = 0; i < ETH_ALEN; i++) {
			val = simple_strtol(pos, &endp, 16);
			if (val > 0xff) {
				skw_warn("larger than 0xff, val: 0x%lx\n", val);
				break;
			}

			if (endp == pos || (*endp != 0 && *endp != ',')) {
				skw_warn("endp: %c(0x%x), pos: %p, endp: %p\n",
					 *endp, *endp, pos, endp);
				break;
			}

			addr[idx++] = val;
			pos = endp + 1;

			if (*endp == 0 && idx == ETH_ALEN)
				skw_ether_copy(cfg->mac, addr);
		}
	} else if (!strcmp(key, "dma_addr_align")) {
		if (skw_get_data(data, str, sizeof(str), '<', '>') > 0) {
			val = simple_strtol(str, &endp, 0);
			if (*endp == 0)
				cfg->dma_addr_align = val;
		}
	} else if (!strcmp(key, "reorder_timeout")) {
		if (skw_get_data(data, str, sizeof(str), '<', '>') > 0) {
			val = simple_strtol(str, &endp, 0);
			if (*endp == 0)
				cfg->reorder_timeout = val;
		}
	} else if (!strcmp(key, "offchan_tx")) {
		if (skw_get_data(data, str, sizeof(str), '<', '>') > 0) {
			val = simple_strtol(str, &endp, 0);
			if (*endp != 0)
				return 0;

			if (val == 0)
				clear_bit(SKW_CFG_FLAG_OFFCHAN_TX, &cfg->flags);
			else if (val == 1)
				set_bit(SKW_CFG_FLAG_OFFCHAN_TX, &cfg->flags);
			else
				skw_warn("invalid offchan_tx: %s\n", str);
		}
	} else if (!strcmp(key, "overlay_mode")) {
		if (skw_get_data(data, str, sizeof(str), '<', '>') > 0) {
			val = simple_strtol(str, &endp, 0);

			if (*endp != 0)
				return 0;

			if (val == 0)
				clear_bit(SKW_CFG_FLAG_OVERLAY_MODE, &cfg->flags);
			else if (val == 1)
				set_bit(SKW_CFG_FLAG_OVERLAY_MODE, &cfg->flags);
			else
				skw_warn("invalid overlay_mode: %s\n", str);
		}
	} else {
		skw_dbg("unsupport key: %s\n", key);
	}

	return 0;
}

static int skw_calib_parser(struct skwifi_cfg *config, char *key, char *data)
{
	int len;
	long val;
	char *endp;
	char str[SKW_LINE_BUFF_LEN] = {0};
	struct skw_cfg_calib *calib = config->priv;

	if (calib == NULL)
		return -EINVAL;

	if (!strcmp(key, "strict_mode")) {
		if (skw_get_data(data, str, sizeof(str), '<', '>') <= 0)
			return 0;

		val = simple_strtol(str, &endp, 0);

		if (*endp != 0)
			return 0;

		if (val == 0)
			clear_bit(SKW_CFG_CALIB_STRICT_MODE, &calib->flags);
		else if (val == 1)
			set_bit(SKW_CFG_CALIB_STRICT_MODE, &calib->flags);
		else
			skw_warn("invalid strict mode: %s\n", str);

	} else if (!strcmp(key, "chip")) {
		len = skw_get_data(data, str, SKW_LINE_BUFF_LEN, '"', '"');
		if (len == 0)
			memset(calib->chip, 0x0, sizeof(calib->chip));
		else if (len > 0)
			strlcpy(calib->chip, str, sizeof(calib->chip) - 1);
		else
			skw_dbg("invalid chip: %s\n", data);

	} else if (!strcmp(key, "project")) {
		len = skw_get_data(data, str, SKW_LINE_BUFF_LEN, '"', '"');
		if (len == 0)
			memset(calib->project, 0x0, sizeof(calib->project));
		else if (len > 0)
			strlcpy(calib->project, str, sizeof(calib->project) - 1);
		else
			skw_dbg("invalid project: %s\n", data);

	} else {
		skw_dbg("unsupport key: %s\n", key);
	}

	return 0;
}

static int skw_regdom_parser(struct skwifi_cfg *config, char *key, char *data)
{
	int len;
	char str[SKW_LINE_BUFF_LEN] = {0};
	struct skw_cfg_regd *regd = config->priv;

	if (regd == NULL)
		return -EINVAL;

	if (!strcmp(key, "country")) {
		len = skw_get_data(data, str, SKW_LINE_BUFF_LEN, '"', '"');
		if (len == 0)
			memset(regd->country, 0x0, 2);
		else if (len == 2 && is_skw_valid_reg_code(str))
			memcpy(regd->country, str, 2);
		else
			skw_dbg("invalid country: %s\n", data);
	} else {
		skw_dbg("unsupport key: %s\n", key);
	}

	return 0;
}

static int skw_roam_parser(struct skwifi_cfg *config, char *key, char *data)
{
	return 0;
}

static struct skwifi_cfg  g_cfg_table[] = {
	{
		.name = "config",
		.parser = skw_config_parser,
	},
	{
		.name = "calib",
		.parser = skw_calib_parser,
	},
	{
		.name = "regdom",
		.parser = skw_regdom_parser,
	},
	{
		.name = "roaming",
		.parser = skw_roam_parser,
	},
	{
		.name = NULL,
		.parser = NULL,
		.priv = NULL,
	}
};

void skw_update_config(struct device *dev, const char *name, struct skw_config *config)
{
	int i;
	const struct firmware *fw;

	if (request_firmware(&fw, name, dev))
		return;

	skw_dbg("load %s successful\n", name);

	for (i = 0; g_cfg_table[i].name != NULL; i++) {
		if (!strcmp(g_cfg_table[i].name, "config"))
			g_cfg_table[i].priv = &config->def;
		else if (!strcmp(g_cfg_table[i].name, "calib"))
			g_cfg_table[i].priv = &config->calib;
		else if (!strcmp(g_cfg_table[i].name, "regdom"))
			g_cfg_table[i].priv = &config->regd;
		else if (!strcmp(g_cfg_table[i].name, "roaming"))
			g_cfg_table[i].priv = NULL;
		else {
			g_cfg_table[i].priv = NULL;
			skw_warn("section: %s not support\n", g_cfg_table[i].name);
		}
	}

	skw_parser(g_cfg_table, fw->data, fw->size);

	release_firmware(fw);
}
