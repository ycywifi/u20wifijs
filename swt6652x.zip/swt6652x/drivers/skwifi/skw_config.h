#ifndef __SKW_CONFIG_H__
#define __SKW_CONFIG_H__

#include <linux/kernel.h>
#include <linux/etherdevice.h>

#define SKW_CFG_FLAG_OVERLAY_MODE           0
#define SKW_CFG_FLAG_STA_EXT                1
#define SKW_CFG_FLAG_SAP_EXT                2
#define SKW_CFG_FLAG_P2P_DEV                3
#define SKW_CFG_FLAG_OFFCHAN_TX             4
#define SKW_CFG_FLAG_REPEATER               5

struct skw_cfg_default {
	unsigned long flags;

	char ifname[4][IFNAMSIZ];

	u8 mac[ETH_ALEN];
	u8 dma_addr_align;
	u8 reorder_timeout;
};

#define SKW_CFG_REGD_COUNTRY_CODE           0
#define SKW_CFG_REGD_SELF_MANAGED           1
#define SKW_CFG_REGD_IGNORE_USER            2
#define SKW_CFG_REGD_IGNORE_COUNTRY_IE      3

struct skw_cfg_regd {
	unsigned long flags;
	char country[2];
};

#define SKW_CFG_CALIB_STRICT_MODE           0
#define SKW_CFG_CALIB_CHIP_NAME             1
#define SKW_CFG_CALIB_PROJECT_NAME          2
#define SKW_CFG_CALIB_EXTRA_ID              3

struct skw_cfg_calib {
	unsigned long flags;

	char chip[16];
	char project[16];
	int  extra_id;
};

struct skw_config {
	struct skw_cfg_default def;
	struct skw_cfg_calib calib;
	struct skw_cfg_regd regd;
};

void skw_update_config(struct device *dev, const char *name, struct skw_config *config);
#endif
